from setuptools import setup

setup(name='chrisvis',
      version='0.1',
      description='Useful visualizations for Chris',
      packages=['chrisvis'],
      zip_safe=False)
